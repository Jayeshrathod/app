SchoolQuiz
@version 1.0
@created Feb 27, 2014
@copyright (c) 2014-present Ujamshi Khandla - http://uckhandla.com
 * Free for non-commercial use
=============
This is a quiz application for standard 6-7-8.
The questions are based on curriculum of standard 6-7-8 of the Gujarat Government Primary Schools.

### NOTE on using this quiz in schools or sharing
If you use/share this quiz, please do not remove or replace the names of the authors and contributors from the quiz.
Please give a credit to original authors and contributors who spent their valuable time and money to develop such a software and content.

### (Copyright)
We are known that some schools are using our SchoolQuiz on their website and they removed our names, it is not fair. 
However SchoolQuiz is free to use, please give a credit note at the bottom of the the pages where it displayed.

### SchoolQuiz Support or Contact
For more information or help, please visit [Ujamshi Khandla's Educational Webiste](http://uckhandla.com/edu/)

### Authors and Contributors
Ujamshi Khandla [@uckhandla](https://github.com/uckhandla) and Mahendra Solanki [@mmsolanki](https://github.com/mmsolanki) founded this SchoolQuiz.
