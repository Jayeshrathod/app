var studentsJSON = {
	"students": [
		{
			"std": "8",
			"name": "Student 1",
			"rollnumber": "1",
			"grnumber": "0"
		},
		{
			"std": "8",
			"name": "Student 2",
			"rollnumber": "2",
			"grnumber": "0"
		},
		

		{
			"std": "7",
			"name": "Student 1",
			"rollnumber": "1",
			"grnumber": "0"
		},
		{
			"std": "7",
			"name": "Student 2",
			"rollnumber": "2",
			"grnumber": "0"
		},
		
		{
			"std": "6",
			"name": "Student 1",
			"rollnumber": "1",
			"grnumber": "0"
		},
		{
			"std": "6",
			"name": "Student 2",
			"rollnumber": "2",
			"grnumber": "0"
		}
	]

};
